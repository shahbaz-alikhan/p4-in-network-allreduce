acn-p4app
=========

The [p4app](https://github.com/p4lang/p4app/tree/rc-2.0.0) python libraries adapted for the course Advanced Computer Networks at VU Amsterdam

See [here](https://github.com/vuhpdc/acn-sml) for example usage